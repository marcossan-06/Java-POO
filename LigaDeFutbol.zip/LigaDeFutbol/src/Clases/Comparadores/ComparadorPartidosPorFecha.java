package Clases.Comparadores;

import Clases.Partido;

import java.util.Comparator;

public class ComparadorPartidosPorFecha implements Comparator<Partido> {

    //Constructor
    public ComparadorPartidosPorFecha() {
    }

    @Override
    public int compare(Partido o1, Partido o2) {
        if (o1.getFechaPartido().isAfter(o2.getFechaPartido())) {
            return -1;
        }
        else if (o1.getFechaPartido().isBefore(o2.getFechaPartido())) {
            return 1;
        }
        return 0;
    }
}
