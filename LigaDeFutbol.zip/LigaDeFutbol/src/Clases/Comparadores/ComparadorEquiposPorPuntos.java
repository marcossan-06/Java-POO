package Clases.Comparadores;

import Clases.Equipo;

import java.util.Comparator;

public class ComparadorEquiposPorPuntos implements Comparator<Equipo> {

    //Constructor
    public ComparadorEquiposPorPuntos() {
    }

    @Override
    public int compare(Equipo o1, Equipo o2) {
        if (o1.getPuntos() > o2.getPuntos()) {
            return -1;
        }
        else if (o1.getPuntos() < o2.getPuntos()) {
            return 1;
        }
        return 0;
    }
}
