package Clases.Personajes;

import java.time.LocalDate;
import java.time.Period;

public class Jugador extends Persona implements Comparable<Jugador> {

    //Atributos
    private String posicion;
    private int golesMarcados;
    private LocalDate fechaNacimiento;

    //Constructor
    public Jugador(String nombre, int edad, String posicion, LocalDate fechaNacimiento) {
        super(nombre, edad);
        this.fechaNacimiento = fechaNacimiento;
        this.edad = calcularEdad();
        if (posicion.matches("(?i)portero|defensa|mediocentro|delantero")) {
            this.posicion = posicion;
        }
        else {
            System.out.println("Posicion no válida");
        }
    }

    //Getters & Setters
    public int getGolesMarcados() {
        return golesMarcados;
    }

    public void setGolesMarcados(int golesMarcados) {
        this.golesMarcados = golesMarcados;
    }

    //Métodos
    public int calcularEdad() {
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Jugador: " + super.nombre +
                "\nEdad: " + super.edad +
                "\nPosición: " + posicion +
                "\nGoles Marcados: " + golesMarcados +
                "\nFecha Nacimiento: " + fechaNacimiento +
                "\n" + "~".repeat(60));
    }


    @Override
    public int compareTo(Jugador o) {
        if (this.golesMarcados > o.golesMarcados) {
            return -1;
        }
        else if (this.golesMarcados < o.golesMarcados) {
            return 1;
        }
        return 0;
    }
}
