package Clases.Personajes;

public abstract class Persona {
    //Atributos
    protected String nombre;
    protected int edad;

    //Constructor
    public Persona(String nombre, int edad) {
        if (nombre.matches("[A-Z][a-zA-Z\\s]*")) {
            this.nombre = nombre;
        }
        else {
            System.out.println("Nombre no valido");
        }
        this.edad = edad;
    }

    //Getters & Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //Métodos
    public abstract void mostrarInfo();

}
