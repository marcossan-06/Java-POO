package Clases.Personajes;

public class Entrenador extends Persona {
    //Atributos
    private int anyosExperiencia;
    private String estrategia;

    //Constructor

    public Entrenador(String nombre, int edad, int anyosExperiencia, String estrategia) {
        super(nombre, edad);
        this.anyosExperiencia = anyosExperiencia;
        if (estrategia.matches("(?i)defensiva|ofensiva|mixta")) {
            this.estrategia = estrategia;
        }
        else {
            System.out.println("Estrategia no válida.");
        }

    }

    //Métodos
    @Override
    public void mostrarInfo() {
        System.out.println("Entrenador: " + super.nombre +
                "\nEdad: " + super.edad +
                "\nAños Experiencia: " + anyosExperiencia +
                "\nEstrategia: " + estrategia +
                "\n" + "~".repeat(60));
    }




}
