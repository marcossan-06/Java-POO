package Clases;

import Clases.Personajes.Entrenador;
import Clases.Personajes.Jugador;

import java.util.ArrayList;

public class Equipo {

    //Atributos
    private String nombreEquipo;
    private Entrenador entrenador;
    private ArrayList<Jugador> jugadores;
    private int puntos;

    //Constructor
    public Equipo(String nombreEquipo, Entrenador entrenador, ArrayList<Jugador> jugadores) {
        this.nombreEquipo = nombreEquipo;
        this.entrenador = entrenador;
        this.jugadores = jugadores;
    }

    //Getters & Setters
    public String getNombreEquipo() {
        return nombreEquipo;
    }
    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    //Métodos
    public void agregarJugador(Jugador jugador, Liga liga) {
        if (jugadores.size() >= 23) {
            System.out.println("El equipo no puede exceder de 23 jugadores.");
        }
        else {
            jugadores.add(jugador);
            liga.getJugadoresLiga().add(jugador);
        }
    }

    public void mostrarPlantilla() {
        for (Jugador jugador : jugadores) {
            jugador.mostrarInfo();
        }
    }
}
