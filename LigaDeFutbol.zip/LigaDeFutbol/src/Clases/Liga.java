package Clases;

import Clases.Comparadores.ComparadorEquiposPorPuntos;
import Clases.Comparadores.ComparadorPartidosPorFecha;
import Clases.Personajes.Jugador;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class Liga {

    //Atributos
    private LinkedList<Equipo> equipos;
    private ArrayList<Partido> partidosJugados;
    private ArrayList<Jugador> jugadoresLiga;

    //Constructor
    public Liga(LinkedList<Equipo> equipos,ArrayList<Partido> partidosJugados , ArrayList<Jugador> jugadoresLiga) {
        this.equipos = equipos;
        this.jugadoresLiga = jugadoresLiga;
        this.partidosJugados = partidosJugados;
    }

    //Getters & Setters
    public ArrayList<Jugador> getJugadoresLiga() {
        return jugadoresLiga;
    }

    //Métodos
    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public void organizarPartidos() {
        for (Equipo equipoLocal : equipos) {
            for (Equipo equipoVisitante : equipos) {
                if (!equipoLocal.equals(equipoVisitante)) {
                    Partido partido = new Partido(equipoLocal, equipos.get(equipos.indexOf(equipoVisitante)),
                            LocalDate.of(2025, 1, (int) (Math.random()*31)+1));
                    partido.simularPartido();
                    partidosJugados.add(partido);
                }
            }
        }
    }

    public void mostrarTablaDePosiciones() {
        System.out.println("**********************************************");
        System.out.println("*                                            *");
        System.out.println("*           🏆 TABLA DE LA LIGA 🏆           *");
        System.out.println("*                                            *");
        System.out.println("**********************************************");
        equipos.sort(new ComparadorEquiposPorPuntos());

        System.out.println("┌───────────────────────────┬────────┐");
        System.out.printf("│ %-25s │ %-6s │\n", "Equipo", "Puntos");
        System.out.println("├───────────────────────────┼────────┤");

        for (Equipo equipo : equipos) {
            System.out.printf("│ %-25s │ %-6d │\n", equipo.getNombreEquipo(), equipo.getPuntos());
        }

        System.out.println("└───────────────────────────┴────────┘");
    }

    public void mostrarTopJugadores() {
        System.out.println("**********************************************");
        System.out.println("*                                            *");
        System.out.println("*          🏆 MÁXIMOS GOLEADORES 🏆          *");
        System.out.println("*                                            *");
        System.out.println("**********************************************");
        Collections.sort(jugadoresLiga);
        System.out.println("┌───────────────────────────┬────────┐");
        System.out.printf("│ %-25s │ %-6s │\n", "Jugador", "Goles");
        System.out.println("├───────────────────────────┼────────┤");
        for (Jugador jugador : jugadoresLiga) {
            System.out.printf("│ %-25s │ %-6d │\n", jugador.getNombre(), jugador.getGolesMarcados());
        }
    }

    public void mostrarPartidosJugados() {
        partidosJugados.sort(new ComparadorPartidosPorFecha());
        System.out.println("**********************************************");
        System.out.println("*                                            *");
        System.out.println("*           🏆 PARTIDOS JUGADOS 🏆           *");
        System.out.println("*                                            *");
        System.out.println("**********************************************");
        for (Partido partido : partidosJugados) {
            partido.mostrarPartido();
            partido.mostrarMarcador();
        }
    }


}
