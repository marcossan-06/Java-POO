package Clases;

import java.time.LocalDate;
import java.lang.Math;

public class Partido {

    //Atributos
    private Equipo local;
    private Equipo visitante;
    private LocalDate fechaPartido;
    private int golesLocal;
    private int golesVisitante;

    //Constructor
    public Partido(Equipo local, Equipo visitante, LocalDate fechaPartido) {
        this.local = local;
        this.visitante = visitante;
        this.fechaPartido = fechaPartido;
    }

    //Getters & Setters
    public LocalDate getFechaPartido() {
        return fechaPartido;
    }

    public void setFechaPartido(LocalDate fechaPartido) {
        this.fechaPartido = fechaPartido;
    }

    //Métodos
    public void simularPartido() {
        int numJugadorMarcaGol;
        mostrarPartido();
        for (int i = 0; i < 90; i += 15) {
            numJugadorMarcaGol = (int) (Math.random()*local.getJugadores().size());
            if (i == 45) {
                System.out.printf("Acaba la 1a parte (%d - %d)...%n", golesLocal, golesVisitante);
                System.out.println("Comienzan a disputar la 2a parte: ");
            }
            else {
                if (Math.random() < 0.52) {
                    System.out.printf("El equipo %s MARCA UN GOOL!!%n",local.getNombreEquipo());
                    local.getJugadores().get(numJugadorMarcaGol).setGolesMarcados(local.getJugadores().get(numJugadorMarcaGol).getGolesMarcados()+1);
                    golesLocal++;
                }
                else {
                    System.out.printf("El equipo %s MARCA UN GOOL!!%n",visitante.getNombreEquipo());
                    visitante.getJugadores().get(numJugadorMarcaGol).setGolesMarcados(visitante.getJugadores().get(numJugadorMarcaGol).getGolesMarcados()+1);
                    golesVisitante++;
                }
                mostrarMarcador();
            }
        }
        mostrarResultado();
    }

    public void mostrarPartido() {
        System.out.println("========================================");
        System.out.printf("⚽💥  %s VS %s  💥⚽\t\tFecha:%s%n", local.getNombreEquipo().toUpperCase(), visitante.getNombreEquipo().toUpperCase(), fechaPartido);
        System.out.println("========================================");
    }

    public void mostrarMarcador() {
        System.out.println(" ┌─────────────────────┐");
        System.out.printf(" │  ⚽  %2d  -  %2d  ⚽  │\n", golesLocal, golesVisitante);
        System.out.println(" └─────────────────────┘");
    }

    public void mostrarResultado() {
        System.out.println("🏆════════════════════════════════════════⚽");
        if (golesLocal > golesVisitante) {
            System.out.printf("\t\t🔥¡¡VICTORIA PARA %s!!🔥%n",local.getNombreEquipo());
            local.setPuntos(local.getPuntos() + 3);
        }
        else if (golesLocal < golesVisitante) {
            System.out.printf("\t\t🔥¡¡VICTORIA PARA %s!!🔥%n",visitante.getNombreEquipo());
            visitante.setPuntos(visitante.getPuntos() + 3);
        }
        else {
            System.out.printf("\t\t🔥 ¡¡EMPATE!! 🤝 ¡¡Ambos equipos lo dieron todo!!🔥%n");
            local.setPuntos(local.getPuntos() + 1);
            visitante.setPuntos(visitante.getPuntos() + 1);
        }
        System.out.println("⚽════════════════════════════════════════🏆");
    }
}