import Clases.Equipo;
import Clases.Liga;
import Clases.Partido;
import Clases.Personajes.Entrenador;
import Clases.Personajes.Jugador;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {

        //Creo una liga
        LinkedList<Equipo> equipos = new LinkedList<>();
        ArrayList<Jugador> jugadores = new ArrayList<>();
        ArrayList<Partido> partidosJugados = new ArrayList<>();
        Liga liga = new Liga(equipos,partidosJugados ,jugadores);


        //Creo equipos
        ArrayList<Jugador> jugadores1 = new ArrayList<>();
        ArrayList<Jugador> jugadores2 = new ArrayList<>();
        ArrayList<Jugador> jugadores3 = new ArrayList<>();
        Equipo equipo1 = new Equipo("Valencia", new Entrenador("Marcos Sancho", 0, 10, "Ofensiva"), jugadores1);
        Equipo equipo2 = new Equipo("Real Madrid", new Entrenador("Asier Puchol", 0, 15, "Defensiva"),jugadores2);
        Equipo equipo3 = new Equipo("Barcelona", new Entrenador("Fran Sancho", 0, 7, "Mixta"),jugadores3);
        liga.agregarEquipo(equipo1);
        liga.agregarEquipo(equipo2);
        liga.agregarEquipo(equipo3);

        //Creo y añado jugadores a los equipos:
        // Equipo 1: "Valencia"
        Jugador jugador1 = new Jugador("Carlos Gomez", 0, "Delantero", LocalDate.of(1997, 3, 14));
        Jugador jugador2 = new Jugador("Juan Perez", 0, "Mediocentro", LocalDate.of(2000, 7, 9));
        Jugador jugador3 = new Jugador("Luis Hernandez", 0, "Defensa", LocalDate.of(1995, 12, 20));
        Jugador jugador4 = new Jugador("Miguel Alvarez", 0, "Portero", LocalDate.of(1998, 1, 25));
        Jugador jugador5 = new Jugador("Raul Sanchez", 0, "Mediocentro", LocalDate.of(2002, 4, 10));
        Jugador jugador6 = new Jugador("Felipe Castro", 0, "Delantero", LocalDate.of(1999, 8, 15));
        Jugador jugador7 = new Jugador("Adrian Lopez", 0, "Defensa", LocalDate.of(1996, 5, 4));
        Jugador jugador8 = new Jugador("David Martin", 0, "Mediocentro", LocalDate.of(2003, 11, 30));
        Jugador jugador9 = new Jugador("Pablo Garcia", 0, "Delantero", LocalDate.of(1994, 2, 22));
        Jugador jugador10 = new Jugador("Victor Ramirez", 0, "Defensa", LocalDate.of(2001, 9, 17));
        Jugador jugador11 = new Jugador("Victor Perez", 0, "Defensa", LocalDate.of(2001, 9, 17));

        
        // Equipo 2: "Real Madrid"
        Jugador jugador12 = new Jugador("Sergio Diaz", 0, "Mediocentro", LocalDate.of(1993, 6, 18));
        Jugador jugador13 = new Jugador("Fernando Gomez", 0, "Delantero", LocalDate.of(1998, 2, 12));
        Jugador jugador14 = new Jugador("Javier Martinez", 0, "Defensa", LocalDate.of(1995, 4, 23));
        Jugador jugador15 = new Jugador("Antonio Ruiz", 0, "Portero", LocalDate.of(1997, 10, 11));
        Jugador jugador16 = new Jugador("Carlos Rodriguez", 0, "Delantero", LocalDate.of(2000, 5, 9));
        Jugador jugador17 = new Jugador("Manuel Ortega", 0, "Mediocentro", LocalDate.of(2002, 3, 30));
        Jugador jugador18 = new Jugador("Jose Jimenez", 0, "Defensa", LocalDate.of(1999, 8, 3));
        Jugador jugador19 = new Jugador("Raul Moreno", 0, "Delantero", LocalDate.of(1994, 1, 17));
        Jugador jugador20 = new Jugador("Fernando Lopez", 0, "Mediocentro", LocalDate.of(1996, 12, 6));
        Jugador jugador21 = new Jugador("Eduardo Sanchez", 0, "Defensa", LocalDate.of(2001, 11, 19));
        Jugador jugador22 = new Jugador("Eduardo Sancho", 0, "Defensa", LocalDate.of(2001, 11, 19));


        // Equipo 3: "Barcelona"
        Jugador jugador23 = new Jugador("Martin Gonzalez", 0, "Delantero", LocalDate.of(1992, 8, 13));
        Jugador jugador24 = new Jugador("Andres Gomez", 0, "Portero", LocalDate.of(1999, 3, 22));
        Jugador jugador25 = new Jugador("Ricardo Torres", 0, "Defensa", LocalDate.of(2001, 7, 10));
        Jugador jugador26 = new Jugador("Carlos Herrera", 0, "Mediocentro", LocalDate.of(1998, 5, 5));
        Jugador jugador27 = new Jugador("Jose Perez", 0, "Delantero", LocalDate.of(1996, 12, 15));
        Jugador jugador28 = new Jugador("Juan Martinez", 0, "Mediocentro", LocalDate.of(2000, 9, 2));
        Jugador jugador29 = new Jugador("Oscar Diaz", 0, "Defensa", LocalDate.of(1997, 11, 14));
        Jugador jugador30 = new Jugador("Raul Jimenez", 0, "Delantero", LocalDate.of(2003, 4, 1));
        Jugador jugador31 = new Jugador("Victor Hernandez", 0, "Mediocentro", LocalDate.of(2001, 10, 17));
        Jugador jugador32 = new Jugador("Antonio Gonzalez", 0, "Defensa", LocalDate.of(1995, 6, 9));
        Jugador jugador33 = new Jugador("Antonio Perez", 0, "Defensa", LocalDate.of(1995, 6, 9));

        Jugador[] jugadoresArray = {jugador1, jugador2, jugador3, jugador4, jugador5, jugador6, jugador7, jugador8, jugador9, jugador10, jugador11,
                jugador12, jugador13, jugador14, jugador15, jugador16, jugador17, jugador18, jugador19, jugador20, jugador21,
                jugador22, jugador23, jugador24, jugador25, jugador26, jugador27, jugador28, jugador29, jugador30, jugador31,
                jugador32, jugador33};

        for (int i = 0; i < 33; i++) {
            if (i < 11){
                equipo1.agregarJugador(jugadoresArray[i], liga);
            }
            else if (i < 22) {
                equipo2.agregarJugador(jugadoresArray[i], liga);
            }
            else {
                equipo3.agregarJugador(jugadoresArray[i], liga);
            }
        }

        liga.organizarPartidos();
        liga.mostrarTablaDePosiciones();
        liga.mostrarTopJugadores();
        liga.mostrarPartidosJugados();
    }
}