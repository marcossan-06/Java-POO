module org.dam.calcufx {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.marcos.calcufx to javafx.fxml;
    exports org.marcos.calcufx;
}