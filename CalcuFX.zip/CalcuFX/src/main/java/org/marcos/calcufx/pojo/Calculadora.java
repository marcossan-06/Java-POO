package org.marcos.calcufx.pojo;

public class Calculadora{
private double op1;
private double op2;

public Calculadora()
{
    this.op1=0;
    this.op2=0;
}

public Calculadora(double op1, double op2) {
    this.op1 = op1;
    this.op2 = op2;
}

public double getOp1() {
    return op1;
}

public void setOp1(int op1) {
    this.op1 = op1;
}

public double getOp2() {
    return op2;
}

public void setOp2(int op2) {
    this.op2 = op2;
}

@Override
public String toString() {
    return "Calculadora{" + "op1=" + op1 + ", op2=" + op2 + '}';
}

public double Suma(){
    return this.op1+this.op2;
}

public double Resta() {
    return this.op1-this.op2;
}

public double Multiplicar() {
    return this.op1*this.op2;
}

public double Dividir() {
    return this.op1/this.op2;
}
}


