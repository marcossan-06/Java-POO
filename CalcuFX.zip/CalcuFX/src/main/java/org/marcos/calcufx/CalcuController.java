package org.marcos.calcufx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import org.marcos.calcufx.pojo.Calculadora;

public class CalcuController {
    @FXML
    private TextField op1;
    @FXML
    private TextField op2;
    @FXML
    private TextField rdo;

    @FXML
    private void Sumar(ActionEvent event) {

        try {
            double op1 = Double.parseDouble(this.op1.getText().replace(",", "."));
            double op2 = Double.parseDouble(this.op2.getText().replace(",", "."));
            Calculadora miCalculadora = new Calculadora(op1, op2);
            double resultado = miCalculadora.Suma();
            this.rdo.setText(resultado + "");

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText(null);
            alert.setTitle("Error en la entrada de datos");
            alert.setContentText("Error en el formato");
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @FXML
    private void Restar(ActionEvent event) {

        try {
            double op1 = Double.parseDouble(this.op1.getText().replace(",", "."));
            double op2 = Double.parseDouble(this.op2.getText().replace(",", "."));
            Calculadora miCalculadora = new Calculadora(op1, op2);
            double resultado = miCalculadora.Resta();
            this.rdo.setText(resultado + "");

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText(null);
            alert.setTitle("Error en la entrada de datos");
            alert.setContentText("Error en el formato");
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @FXML
    private void Multiplicar(ActionEvent event) {

        try {
            double op1 = Double.parseDouble(this.op1.getText().replace(",", "."));
            double op2 = Double.parseDouble(this.op2.getText().replace(",", "."));
            Calculadora miCalculadora = new Calculadora(op1, op2);
            double resultado = miCalculadora.Multiplicar();
            this.rdo.setText(resultado + "");

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText(null);
            alert.setTitle("Error en la entrada de datos");
            alert.setContentText("Error en el formato");
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @FXML
    private void Dividir(ActionEvent event) {

        try {
            double op1 = Double.parseDouble(this.op1.getText().replace(",", "."));
            double op2 = Double.parseDouble(this.op2.getText().replace(",", "."));
            Calculadora miCalculadora = new Calculadora(op1, op2);
            double resultado = miCalculadora.Dividir();
            this.rdo.setText(resultado + "");

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText(null);
            alert.setTitle("Error en la entrada de datos");
            alert.setContentText("Error en el formato");
            alert.showAndWait();
            e.printStackTrace();
        }
    }

}